import { http } from './http';
import { createCrudApi } from './crudFactory';
import type { ApiResponse } from '@/types/common';
import type { JenisSurat, SuratKeterangan, SuratKeteranganCetakData } from '@/types/entities';

export interface SuratKeteranganPayload {
  mahasiswaId: number;
  jenisSurat: JenisSurat;
  nomorSurat?: string | null;
  tanggalInput: string;
  semester?: number | null;
  alasan?: string | null;
}

const baseApi = createCrudApi<SuratKeterangan, SuratKeteranganPayload, Partial<SuratKeteranganPayload>>(
  'laporan/cetak-surat'
);

export const suratKeteranganApi = {
  ...baseApi,

  async cetakData(id: number | string): Promise<SuratKeteranganCetakData> {
    const { data } = await http.get<ApiResponse<SuratKeteranganCetakData>>(`/laporan/cetak-surat/${id}/cetak`);
    return data.data;
  },

  async cetakPdf(id: number | string): Promise<Blob> {
    const { data } = await http.get(`/laporan/cetak-surat/${id}/pdf`, { responseType: 'blob' });
    return data;
  },
};
