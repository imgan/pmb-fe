import { createCrudApi } from './crudFactory';
import type { Kurikulum } from '@/types/entities';

export interface KurikulumPayload {
  kode: string;
  mataKuliah: string;
  sksTeori?: number;
  sksPraktek?: number;
  sksLab?: number;
  sksSimulasi?: number;
  semester?: number | null;
  bidangMinat?: number;
  tahunAkademik?: number | null;
}

export const kurikulumApi = createCrudApi<Kurikulum, KurikulumPayload, Partial<KurikulumPayload>>('prodi/kurikulum');
