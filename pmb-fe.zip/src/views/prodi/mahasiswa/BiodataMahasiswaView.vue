<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Biodata Mahasiswa" subtitle="Kelola biodata lengkap mahasiswa." />
    <ComingSoonPanel icon="badge" />
  </div>
</template>
