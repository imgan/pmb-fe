<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Habis Masa Studi" subtitle="Daftar mahasiswa yang telah melewati batas masa studi." />
    <ComingSoonPanel icon="event_busy" />
  </div>
</template>
