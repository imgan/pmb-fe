<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Mahasiswa Cuti" subtitle="Daftar mahasiswa yang sedang mengambil cuti akademik." />
    <ComingSoonPanel icon="pause_circle" />
  </div>
</template>
