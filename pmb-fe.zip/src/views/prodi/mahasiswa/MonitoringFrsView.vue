<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Monitoring FRS" subtitle="Pantau status pengisian FRS (Formulir Rencana Studi) mahasiswa." />
    <ComingSoonPanel icon="fact_check" />
  </div>
</template>
