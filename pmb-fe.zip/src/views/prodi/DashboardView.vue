<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Beranda Prodi" subtitle="Ringkasan modul Program Studi." />
    <ComingSoonPanel icon="school" message="Modul Program Studi sedang dalam pengembangan dan akan segera hadir." />
  </div>
</template>
