<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Matakuliah Aktif" subtitle="Daftar mata kuliah aktif per semester berjalan." />
    <ComingSoonPanel icon="auto_stories" />
  </div>
</template>
