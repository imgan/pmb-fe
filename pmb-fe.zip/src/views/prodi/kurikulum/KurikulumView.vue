<script setup lang="ts">
import { reactive, ref, watch } from 'vue';
import PageHeader from '@/components/layout/PageHeader.vue';
import DataTable, { type DataTableColumn } from '@/components/ui/DataTable.vue';
import Pagination from '@/components/ui/Pagination.vue';
import SearchInput from '@/components/ui/SearchInput.vue';
import TextInput from '@/components/ui/TextInput.vue';
import RowActions from '@/components/ui/RowActions.vue';
import AppButton from '@/components/ui/AppButton.vue';
import ConfirmDialog from '@/components/ui/ConfirmDialog.vue';
import Modal from '@/components/ui/Modal.vue';
import { kurikulumApi, type KurikulumPayload } from '@/api/kurikulum';
import { extractErrorMessage } from '@/api/http';
import { useCrudPage } from '@/composables/useCrudPage';
import { usePermission } from '@/composables/usePermission';
import { MENU } from '@/constants/menuCodes';
import type { Kurikulum } from '@/types/entities';

const { canCreate, canUpdate, canDelete } = usePermission(MENU.PRODI_KURIKULUM_MANAGEMENT);

const {
  items,
  meta,
  page,
  search,
  loading,
  error,
  sortBy,
  sortDir,
  handleSort,
  deleteTarget,
  deleting,
  isFormOpen,
  editingItem,
  fetchItems,
  openCreate,
  openEdit,
  closeForm,
  onSaved,
  requestDelete,
  cancelDelete,
  confirmDelete,
} = useCrudPage({
  fetchList: kurikulumApi.list,
  remove: kurikulumApi.remove,
});

fetchItems();

const columns: DataTableColumn[] = [
  { key: 'kode', label: 'Kode', sortable: true },
  { key: 'mataKuliah', label: 'Mata kuliah', sortable: true },
  { key: 'sksTeori', label: 'SKS Teori', align: 'center' },
  { key: 'sksPraktek', label: 'SKS Praktek', align: 'center' },
  { key: 'sksLab', label: 'SKS Lab', align: 'center' },
  { key: 'sksSimulasi', label: 'SKS Simulasi', align: 'center' },
  { key: 'sksTotal', label: 'SKS Total', align: 'center' },
  { key: 'semester', label: 'Semester', align: 'center', sortable: true },
  { key: 'bidangMinat', label: 'Bidang Minat', align: 'center' },
  { key: 'tahunAkademik', label: 'tahun akademik', align: 'center', sortable: true },
];

interface FormState {
  kode: string;
  mataKuliah: string;
  sksTeori: number;
  sksPraktek: number;
  sksLab: number;
  sksSimulasi: number;
  semester: number | '';
  bidangMinat: number;
  tahunAkademik: number | '';
}

const emptyForm = (): FormState => ({
  kode: '',
  mataKuliah: '',
  sksTeori: 0,
  sksPraktek: 0,
  sksLab: 0,
  sksSimulasi: 0,
  semester: '',
  bidangMinat: 0,
  tahunAkademik: '',
});

const form = reactive(emptyForm());
const formError = ref<string | null>(null);
const errors = reactive<Record<string, string>>({});
const submitting = ref(false);

watch(
  () => [isFormOpen.value, editingItem.value] as const,
  ([open, editing]) => {
    if (!open) return;
    Object.keys(errors).forEach((k) => delete errors[k]);
    formError.value = null;
    Object.assign(form, emptyForm());
    if (editing) {
      const item = editing as Kurikulum;
      form.kode = item.kode;
      form.mataKuliah = item.mataKuliah;
      form.sksTeori = item.sksTeori;
      form.sksPraktek = item.sksPraktek;
      form.sksLab = item.sksLab;
      form.sksSimulasi = item.sksSimulasi;
      form.semester = item.semester ?? '';
      form.bidangMinat = item.bidangMinat;
      form.tahunAkademik = item.tahunAkademik ?? '';
    }
  },
  { immediate: true }
);

const handleSubmit = async () => {
  Object.keys(errors).forEach((k) => delete errors[k]);
  if (!form.kode.trim()) errors.kode = 'Kode wajib diisi';
  if (!form.mataKuliah.trim()) errors.mataKuliah = 'Mata kuliah wajib diisi';
  if (Object.keys(errors).length > 0) return;

  submitting.value = true;
  formError.value = null;
  try {
    const payload: KurikulumPayload = {
      kode: form.kode.trim(),
      mataKuliah: form.mataKuliah.trim(),
      sksTeori: Number(form.sksTeori) || 0,
      sksPraktek: Number(form.sksPraktek) || 0,
      sksLab: Number(form.sksLab) || 0,
      sksSimulasi: Number(form.sksSimulasi) || 0,
      semester: form.semester === '' ? null : Number(form.semester),
      bidangMinat: Number(form.bidangMinat) || 0,
      tahunAkademik: form.tahunAkademik === '' ? null : Number(form.tahunAkademik),
    };
    if (editingItem.value) {
      await kurikulumApi.update(editingItem.value.id, payload);
    } else {
      await kurikulumApi.create(payload);
    }
    onSaved();
  } catch (err) {
    formError.value = extractErrorMessage(err, 'Gagal menyimpan data kurikulum');
  } finally {
    submitting.value = false;
  }
};
</script>

<template>
  <div>
    <PageHeader title="Master Kurikulum" subtitle="Master data kurikulum / mata kuliah.">
      <template v-if="canCreate" #actions>
        <AppButton icon="add" @click="openCreate">Tambah Data</AppButton>
      </template>
    </PageHeader>

    <section class="bg-surface-container-lowest border border-outline-variant rounded-lg overflow-hidden">
      <div class="px-4 py-3 bg-primary text-on-primary text-label-md font-medium">Semua Data Master Kurikulum</div>

      <div class="p-4 border-b border-outline-variant flex justify-end">
        <div class="w-full md:w-64">
          <SearchInput v-model="search" placeholder="Cari kode atau mata kuliah..." />
        </div>
      </div>

      <div v-if="error" class="p-4 text-body-sm text-error bg-error-container">{{ error }}</div>

      <DataTable
        :columns="columns"
        :items="items"
        :loading="loading"
        empty-message="Belum ada data kurikulum"
        :sort-key="sortBy"
        :sort-dir="sortDir"
        @sort="handleSort"
      >
        <template #cell-semester="{ item }">{{ item.semester ?? '-' }}</template>
        <template #cell-tahunAkademik="{ item }">{{ item.tahunAkademik ?? '-' }}</template>
        <template #actions="{ item }">
          <RowActions :can-update="canUpdate" :can-delete="canDelete" @edit="openEdit(item)" @delete="requestDelete(item)" />
        </template>
      </DataTable>

      <Pagination v-model="page" :meta="meta" />
    </section>

    <Modal
      :model-value="isFormOpen"
      :title="editingItem ? 'Ubah Kurikulum' : 'Tambah Kurikulum'"
      size="lg"
      @update:model-value="closeForm"
    >
      <form class="space-y-4" @submit.prevent="handleSubmit">
        <div v-if="formError" class="px-3 py-2 rounded-md bg-error-container text-on-error-container text-body-sm">
          {{ formError }}
        </div>
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <TextInput v-model="form.kode" label="Kode" required :error="errors.kode" />
          <TextInput v-model="form.mataKuliah" label="Mata Kuliah" required :error="errors.mataKuliah" />
        </div>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <TextInput v-model.number="form.sksTeori" type="number" label="SKS Teori" />
          <TextInput v-model.number="form.sksPraktek" type="number" label="SKS Praktek" />
          <TextInput v-model.number="form.sksLab" type="number" label="SKS Lab" />
          <TextInput v-model.number="form.sksSimulasi" type="number" label="SKS Simulasi" />
        </div>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <TextInput v-model.number="form.semester" type="number" label="Semester" />
          <TextInput v-model.number="form.bidangMinat" type="number" label="Bidang Minat" />
          <TextInput v-model.number="form.tahunAkademik" type="number" label="Tahun Akademik" placeholder="mis. 2026" />
        </div>
      </form>
      <template #footer>
        <AppButton variant="secondary" @click="closeForm">Batal</AppButton>
        <AppButton :disabled="submitting" @click="handleSubmit">{{ submitting ? 'Menyimpan...' : 'Simpan' }}</AppButton>
      </template>
    </Modal>

    <ConfirmDialog
      :open="!!deleteTarget"
      title="Hapus Kurikulum"
      :message="`Yakin ingin menghapus kurikulum ${deleteTarget?.mataKuliah ?? ''}?`"
      :loading="deleting"
      @confirm="confirmDelete"
      @cancel="cancelDelete"
    />
  </div>
</template>
