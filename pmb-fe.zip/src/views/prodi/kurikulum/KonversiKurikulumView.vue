<script setup lang="ts">
import PageHeader from '@/components/layout/PageHeader.vue';
import ComingSoonPanel from '@/components/layout/ComingSoonPanel.vue';
</script>

<template>
  <div>
    <PageHeader title="Konversi Kurikulum" subtitle="Konversi mata kuliah antar kurikulum." />
    <ComingSoonPanel icon="sync_alt" />
  </div>
</template>
